package org.example.existing;
//https://www.devmedia.com.br/java-adapters-usando-adapters-de-composicao-e-adapters-de-heranca-em-java/31805
public interface MediaPlayer {
    public void play(String audioType, String fileName);
}
