package sigaa.entidades;

public enum Departamento {
	INF,
	IME,
	ICB,
	IPTSP,
	FL,
	EVZ,
	FCS,
	FAV,
	EMAC
}
