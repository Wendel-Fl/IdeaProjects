package sigaa.entidades;

public enum Formacao {
	TECNICO,
	BACHARELADO,
	LICENCIATURA,
	MESTRADO,
	DOUTORADO,
	PHD
}
