package sigaa.entidades;

public enum Curso {
	ES,
	SI,
	CC,
	IA,
	BIO,
	BIOMED,
	MED,
	ENF,
	BIOTEC,
	LI,
	LE,
	LL,
	LIT,
	MAT,
	EST,
	VET,
	ZOOTEC
}
