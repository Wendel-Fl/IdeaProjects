package sigaa.entidades;

public enum Situacao {
	APROVADO, 
	REPROVADOPORMEDIA,
	REPROVADOPORFALTA
}
