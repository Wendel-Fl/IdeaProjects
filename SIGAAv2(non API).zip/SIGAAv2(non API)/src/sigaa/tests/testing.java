package sigaa.tests;

import static org.junit.Assert.assertEquals;

import org.junit.BeforeClass;
import org.junit.Test;

import sigaa.sistema.Sistema;
import sigaa.usuario.Administrador;

public class testing {
	
	private Sistema sigaav2;
	
	@BeforeClass
	public void setup() {
		sigaav2 = Sistema.getInstance();
	}
	
	@Test
	public void test001() {
		Administrador adm = new Administrador(sigaav2,
				"adm001",
				"12345678",
				"guilherme.santos@discente.ufg.br",
				"Guilherme Santos");
		assertEquals(adm.logar("12345678"), true);
	}
	
	@Test
	public void teste002() {
		
	}

}
